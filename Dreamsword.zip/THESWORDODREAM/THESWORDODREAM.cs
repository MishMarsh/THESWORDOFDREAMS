using Terraria.ModLoader;

namespace THESWORDODREAM
{
	public class THESWORDODREAM : Mod
	{
	}
}