using Terraria.ID;
using Terraria.ModLoader;

namespace THESWORDODREAM.Items
{
	public class HEROSWORD : ModItem
	{
		public override void SetStaticDefaults()
		{
			Tooltip.SetDefault("You're surged with the power of the last terrarian.");
		}

		public override void SetDefaults()
		{
			item.damage = 250;
			item.melee = true;
			item.width = 50;
			item.height = 200;
			item.useTime = 2;
			item.useAnimation = 20;
			item.useStyle = 1;
			item.knockBack = 0;
			item.value = 154200;
			item.rare = 8;
			item.UseSound = SoundID.Item20;
			item.autoReuse = true;
		}
		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.LihzahrdBrick, 100);
			recipe.AddIngredient(ItemID.TerraBlade, 1);
			recipe.AddIngredient(ItemID.BrokenHeroSword, 3);
			recipe.AddIngredient(ItemID.CursedFlame, 10);
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}