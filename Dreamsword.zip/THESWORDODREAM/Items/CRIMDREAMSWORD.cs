using Terraria.ID;
using Terraria.ModLoader;

namespace THESWORDODREAM.Items
{
	public class CRIMDREAMSWORD : ModItem
	{
		public override void SetStaticDefaults() 
		{
			Tooltip.SetDefault("You feel compelled to KILL.");
		}

		public override void SetDefaults() 
		{
			item.damage = 2000000000;
			item.melee = true;
			item.width = 50;
			item.height = 200;
			item.useTime = 2;
			item.useAnimation = 20;
			item.useStyle = 1;
			item.knockBack = 0;
			item.value = 100900;
			item.rare = 11;
			item.UseSound = SoundID.Item20;
			item.autoReuse = true;
		}
		public override void AddRecipes() 
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.LunarBar, 999);
			recipe.AddIngredient(ItemID.StarWrath, 3);
			recipe.AddIngredient(ItemID.BrokenHeroSword, 10);
			recipe.AddIngredient(ItemID.Ichor, 999);
			recipe.AddTile(TileID.DemonAltar);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}